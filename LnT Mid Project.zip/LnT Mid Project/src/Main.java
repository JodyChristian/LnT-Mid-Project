import java.util.ArrayList;
import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	ArrayList<String> KodeKaryawan = new ArrayList<>();
	ArrayList<String> NamaKaryawan = new ArrayList<>();
	ArrayList<String> JenisKelamin = new ArrayList<>();
	ArrayList<String> Jabatan = new ArrayList<>();
	ArrayList<Integer> GajiKaryawan = new ArrayList<>();

	public Main() {
		int choose = 0;
		do {
			System.out.println("1. Insert data karyawan");
			System.out.println("2. View data karyawan");
			System.out.println("3. Update data karyawan");
			System.out.println("4. Delete data karyawan");
			System.out.println("5. Exit");
			System.out.print("Choose: ");

			choose = scan.nextInt();
			scan.nextLine();

			switch (choose) {
			case 1:
				Insert();
				break;

			case 2:
				View();
				break;

			case 3:
				Update();
				break;

			case 4:
				Delete();
				break;

			case 5:
				System.exit(0);
				break;
			}
		} while (choose != 5);
	}

	private void Insert() {
		String kode = "";
		String nama, jenis, jabatan;
		int gaji = 0;
		int bonus = 0;
		int totalBonus = 0;
		int totalGaji = 0;
		boolean unique = false;

		while (!unique) {
			String alphabet1 = String.valueOf((char) (Math.random() * 26 + 'A'));
			String alphabet2 = String.valueOf((char) (Math.random() * 26 + 'A'));
			int numeric = (int) (Math.random() * 9000 + 1000);
			kode = alphabet1 + alphabet2 + "-" + numeric;
			if (!KodeKaryawan.contains(kode)) {
				unique = true;
			}
		}

		do {
			System.out.print("Input nama karyawan [>= 3]: ");
			nama = scan.nextLine();
		} while (nama.length() <= 3);

		do {
			System.out.print("Input jenis kelamin [Laki-laki | Perempuan] (Case Sensitive): ");
			jenis = scan.nextLine();
		} while (!jenis.equals("Laki-laki") && !jenis.equals("Perempuan"));

		do {
			System.out.print("Input jabatan [Manager | Supervisor | Admin] (Case Sensitive): ");
			jabatan = scan.nextLine();
		} while (!jabatan.equals("Manager") && !jabatan.equals("Supervisor") && !jabatan.equals("Admin"));

		if (jabatan.equals("Manager")) {
			gaji = 8000000;
		} else if (jabatan.equals("Supervisor")) {
			gaji = 6000000;
		} else {
			gaji = 4000000;
		}

		if (jabatan.equals("Manager")) {
			bonus = 10;
		} else if (jabatan.equals("Supervisor")) {
			bonus = (int) 7.5;
		} else {
			bonus = 5;
		}

		if (jabatan.equals("Manager")) {
			totalBonus = (int) (gaji * 0.1);
		} else if (jabatan.equals("Supervisor")) {
			totalBonus = (int) (gaji * 0.075);
		} else if (jabatan.equals("Admin")) {
			totalBonus = (int) (gaji * 0.05);
		}

		totalGaji = (gaji - totalBonus);

		KodeKaryawan.add(kode);
		NamaKaryawan.add(nama);
		JenisKelamin.add(jenis);
		Jabatan.add(jabatan);
		GajiKaryawan.add(totalGaji);

		System.out.println("Berhasil menambahkan karyawan dengan id : " + kode);
		System.out.println("Bonus sebesar " + bonus + "%" + " telah diberikan kepada karyawan dengan id " + kode);
		System.out.println("Enter to return");
		scan.nextLine();
	}

	private void View() {
		if (NamaKaryawan.isEmpty()) {
			System.out.println("Tidak ada data karyawan");
			System.out.println("Enter to return");
			scan.nextLine();
		} else {
			sortDataKaryawan();
			for (int i = 0; i < NamaKaryawan.size(); i++) {
				System.out.println("No:" + (i + 1));
				System.out.println("Kode Karyawan:" + (KodeKaryawan.get(i)));
				System.out.println("Nama Karyawan:" + (NamaKaryawan.get(i)));
				System.out.println("JenisKelamin:" + (JenisKelamin.get(i)));
				System.out.println("Jabatan:" + (Jabatan.get(i)));
				System.out.println("Gaji Karyawan:" + (GajiKaryawan.get(i)));
				System.out.println("");
			}
		}
	}

	private void Update() {
		if (NamaKaryawan.isEmpty()) {
			System.out.println("Tidak ada data karyawan");
			System.out.println("Enter to return");
			scan.nextLine();
		} else {
			View();
			int update = 0;
			String updateNama, updateJabatan, updateJenis;
			sortDataKaryawan();

			do {
				System.out.print("Input nomor karyawan yang mau diupdate : ");
				update = scan.nextInt();
				scan.nextLine();
			} while (update < 0 || update > NamaKaryawan.size());

			do {
				System.out.print("Input nama karyawan [>= 3]: ");
				updateNama = scan.nextLine();
			} while (updateNama.length() <= 3);

			do {
				System.out.print("Input jenis kelamin [Laki-laki | Perempuan] (Case Sensitive): ");
				updateJenis = scan.nextLine();
			} while (!updateJenis.equals("Laki-laki") && !updateJenis.equals("Perempuan"));

			do {
				System.out.print("Input jabatan [Manager | Supervisor | Admin] (Case Sensitive): ");
				updateJabatan = scan.nextLine();
			} while (!updateJabatan.equals("Manager") && !updateJabatan.equals("Supervisor")
					&& !updateJabatan.equals("Admin"));

			NamaKaryawan.set(update, updateNama);
			JenisKelamin.set(update, updateJenis);
			Jabatan.set(update, updateJabatan);

			System.out.println("Berhasil mengupdate data karyawan");
			System.out.println("");
		}

	}

	private void Delete() {
		if (NamaKaryawan.isEmpty()) {
			System.out.println("Tidak ada data karyawan");
			System.out.println("Enter to return");
			scan.nextLine();
		} else {
			View();
			int input = 0;
			do {
				System.out.print("Input nomor urutan karyawan yang ingin dihapus: ");
				input = scan.nextInt();
				scan.nextLine();
			} while (input < 0 || input > NamaKaryawan.size());

			if (input != 0) {
				KodeKaryawan.remove(input - 1);
				NamaKaryawan.remove(input - 1);
				JenisKelamin.remove(input - 1);
				Jabatan.remove(input - 1);
				GajiKaryawan.remove(input - 1);
				System.out.println("data karyawan berhasil dihapus");
			} else if (input == 0) {
				System.out.println(" ");
			}
		}

	}

	private void sortDataKaryawan() {
		for (int i = 0; i < NamaKaryawan.size() - i; i++) {
			for (int j = 0; j < NamaKaryawan.size() - i - 1; i++) {
				if (NamaKaryawan.get(j).compareTo(NamaKaryawan.get(j + 1)) > 0) {
					String tempNamaKaryawan = NamaKaryawan.get(j);
					NamaKaryawan.set(j, NamaKaryawan.get(j + 1));
					NamaKaryawan.set(j + 1, tempNamaKaryawan);

					String tempKodeKaryawan = KodeKaryawan.get(j);
					KodeKaryawan.set(j, KodeKaryawan.get(j + 1));
					KodeKaryawan.set(j + 1, tempKodeKaryawan);

					String tempJenisKelamin = JenisKelamin.get(j);
					JenisKelamin.set(j, JenisKelamin.get(j + 1));
					JenisKelamin.set(j + 1, tempJenisKelamin);

					String tempJabatan = Jabatan.get(j);
					Jabatan.set(j, Jabatan.get(j + 1));
					Jabatan.set(j + 1, tempJabatan);

					int tempGajiKaryawan = GajiKaryawan.get(j);
					GajiKaryawan.set(j, GajiKaryawan.get(j + 1));
					GajiKaryawan.set(j + 1, tempGajiKaryawan);

				}
			}
		}
	}

	public static void main(String[] args) {
		new Main();

	}

}
